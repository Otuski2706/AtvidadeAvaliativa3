package com.example.br.edu.ifsp.dmos5.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.br.edu.ifsp.dmos5.R;
import com.example.br.edu.ifsp.dmos5.dao.ContactDao;
import com.example.br.edu.ifsp.dmos5.dao.Order;
import com.example.br.edu.ifsp.dmos5.model.Contact;
import com.example.br.edu.ifsp.dmos5.view.adapter.ContactSpinnerAdapter;

import java.util.List;

public class ContactsActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner mSpinner;
    private TextView nameTextView;
    private TextView telTextView;
    private Button newButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findById();
        mSpinner.setOnItemSelectedListener(this);
        populateSpinner();

    }

    @Override
    protected void onResume() {
        super.onResume();
        mSpinner.setSelection(0);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Contact contact = (Contact) mSpinner.getItemAtPosition(position);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void findById(){
        mSpinner = findViewById(R.id.spinner_contacts);
    }

    private void populateSpinner(){
        List<Contact> dataset = new ContactDao().findAll(Order.ASCENDING);
        dataset.add(0, null);
        ContactSpinnerAdapter adapter = new ContactSpinnerAdapter(this, android.R.layout.simple_spinner_item, dataset);
        mSpinner.setAdapter(adapter);
    }


}