package com.example.br.edu.ifsp.dmos5.dao;

public enum Order {
    ASCENDING
}
