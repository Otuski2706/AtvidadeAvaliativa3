package com.example.br.edu.ifsp.dmos5.dao;

import com.example.br.edu.ifsp.dmos5.model.Contact;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ContactDao {

    private final List<Contact> database;

    public ContactDao(){
        database = new ArrayList<>(30);
    }

    public void addContact(Contact contact) {
        if(contact != null) {
            database.add(contact);
        }
    }

    public Contact findById(int id) {
        return database.stream()
                .filter(contact1 -> contact1.getId()== id)
                .findAny()
                .orElse(null);
    }

    public List<Contact> findAll() {
        return database;
    }

    public List<Contact> findAll(Order order) {
        Comparator<Contact> comparator = Comparator.comparing(Contact::getApelido);
        if(order == Order.ASCENDING) {
            return database.stream()
                    .sorted(comparator)
                    .collect(Collectors.toList());
        }else{
            return database.stream()
                    .sorted(comparator.reversed())
                    .collect(Collectors.toList());
        }
    }
}

