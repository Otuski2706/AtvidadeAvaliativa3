package com.example.br.edu.ifsp.dmos5.dao;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.example.br.edu.ifsp.dmos5.model.User;

public class UserDao {

    private final List<User> database;

    public UserDao(){
        database = new ArrayList<>(30);
    }

    public int addUser(String s, String p) {
            int i = database.size()+1;
            User user = new User(i, s, p);
            database.add(user);
            return i;
    }

    public boolean verify(String s, String p) {

        if (BuscaString((ArrayList<User>) database, s)==-1){
            return true;
        }else{
            return false;
        }
    }

    public static int BuscaString(ArrayList<User> lista, String busca) {
        for (int i = 0; i < lista.size(); i++)
            if (lista.get(i).equals(busca)) return i;
        return -1;
    }
}
